
using System.IO;
using System.Text;
using System;
using Moq;
using DLL_CustomerService_For_MOQ_test;

namespace CustomerService_MoqTest_Demo;

public class CustomerServiceTest
{
    private readonly Mock<ICustomerRepository> _repository;

    public CustomerServiceTest()
    {
        _repository = new Mock<ICustomerRepository>();
    }

    [Fact]
    public void SaveCustomer_ShouldThrowException_WhenNull()
    {
        var service = new CustomerService(_repository.Object);

        Action actual = () => service.SaveCustomer(null);

        Assert.Throws<ArgumentNullException>(actual);
    }

    [Fact]
    public void SaveCustomer_ShouldThrowException_WhenNameEmpty()
    {
        var customer = new Customer { Name = String.Empty };
        var service = new CustomerService(_repository.Object);

        Action actual = () => service.SaveCustomer(customer);

        var exception = Assert.Throws<InvalidDataException>(actual);
        Assert.Equal("Name cannot be empty", exception.Message);
    }

    [Fact]
    public void SaveCustomer_ShouldThrowException_WhenEmailEmpty()
    {
        var customer = new Customer{Name = "Prabhav", Email = String.Empty};
        var service = new CustomerService(_repository.Object);
        Action actual = () => {service.SaveCustomer(customer);};
        var Ex = Assert.Throws<InvalidDataException>(actual);
        Assert.Equal("Email cannot be empty", Ex?.Message);
    }


    [Fact]
    public void SaveCustomer_ShouldThrowException_WhenCustomerExists()
    {
        var customer = new Customer{Id = 0, Name = "Prabhav",Email = "Prabhav.khalya@yash.com"};
        _repository.Setup(x=>x.Search(It.IsAny<string>())).Returns(customer);
        var service = new CustomerService(_repository.Object);

        Action act = () => {service.SaveCustomer(customer);};

        var exception = Assert.Throws<InvalidDataException>(act);

        Assert.Equal("Customer already exists", exception?.Message);

    }

    [Fact]
    public void  SaveCustomer_ShouldThrowException_WhenVaildCustomerAddRequest()
    {
        var customer = new Customer{Id =0, Name = "Prabhav", Email ="Prabhav.khalya@yash.com"};
        int customerId = 20;
        _repository.Setup(x=>x.Search(It.IsAny<string>())).Returns((Customer)null);
        _repository.Setup(x=>x.Add(It.IsAny<Customer>())).Returns(customerId);
        var service = new CustomerService(_repository.Object);
        var custId = service.SaveCustomer(customer);

        _repository.Verify(x => x.Add(customer), Times.Once());
        Assert.Equal(customerId, custId);

    }
}